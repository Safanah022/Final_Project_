
<h1 align="center"> Final project within the course
, "Developing AI Applications with Python and Flask"  </h1>

